#pragma once
#include <iostream>
#include <conio.h>
#include "Graphic.h"
#include "Console.h" 

using namespace std;

class Settings
{
private:
	void DrawSettingsScene();

public:
	void ShowSettings();
};

