#pragma once
#include <iostream>
#include <conio.h>
#include "Graphic.h"
#include "Console.h" 

using namespace std;

class Credits {
private:
	void ShowFirstSlide();
	void ShowSecondSlide();
public:
	void ShowCredits();
};

